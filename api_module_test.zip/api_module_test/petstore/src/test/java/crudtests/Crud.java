package crudtests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;



import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import payloads.UserModels;
import utilities.ExtentReportsListener;

@Listeners(ExtentReportsListener.class)
public class Crud {
	public UserModels um;
	
	//setup before class
	@BeforeClass
	public void setUp() {
		um= new UserModels(3,167,3,"placed",true);
		RestAssured.useRelaxedHTTPSValidation();
		
	}
	// method to verify the status code, and the response data of the getbyId method
	@Test
	public void verifyGetAll() {
		Response res= UserEndpoints.getListUser();
		res.then().log().all().contentType("application/json")
		.body("[0].status", equalTo("pending"));
		assertEquals(res.getStatusCode(), 200);
	}
	// method to verify the status code, and the response data of the getbyId method
	@Test
	public void verifyGetSingle() {
		Response response = UserEndpoints.getUser(um.getId());
		response.then().log().all().contentType("application/json")
		.body("[0].pending", equalTo("7"));
		assertEquals(response.getStatusCode(), 200);
	}
	//method to verify the status code, and the response data of the getbyId method
	@Test
	public void verifyCreate() {
		
		Response response = UserEndpoints.createOrder(um);
		response.then().log().all().contentType("application/json")
		.body("[0].status", equalTo("pending"));
		assertEquals(response.getStatusCode(), 200);
	}
	 //method  to verify the delete request
	@Test
	public void deleteReqTest() {
		Response response = UserEndpoints.deleteOrder(um.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
	//method to verify the schema for the get method
	@Test
	public void schemavalidation() {
		
		Response response = UserEndpoints.getUser(3);
		response.then().assertThat().body(matchesJsonSchema(
				new File(System.getProperty("user.dir")+"\\src\\test\\resource\\schema.json")));
	}
	
	//there is no put and patch request in the api I got 
	

}
