package karatetests;

import com.intuit.karate.junit5.Karate;

public class Runner {
	@Karate.Test
	 public Karate runTest() {
		 
		return Karate.run("crud.feature").relativeTo(getClass());
		 
	 }

}
